FB Messenger Bot PHP API Sample
========================

This is an example for Facebook Messenger PHP Bot API - [https://github.com/pimax/fb-messenger-php](https://github.com/pimax/fb-messenger-php)

REQUIREMENTS
------------
The minimum requirement is that your Web server supports PHP 5.4.

INSTALLATION
------------

```
composer install
```

```
cp config_sample.php config.php
```

Specify token and verify_token in the config.php
